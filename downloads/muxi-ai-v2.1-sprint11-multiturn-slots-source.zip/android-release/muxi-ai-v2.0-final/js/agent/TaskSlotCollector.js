const CANCEL_PATTERN = /^(?:取消|取消任务|停止|停止任务|不用了|先不做了)[。！!？?\s]*$/i;
const SKIP_PATTERN = /^(?:跳过|没有|暂无|用默认|默认即可|直接生成)[。！!？?\s]*$/i;

function clone(value) {
  return value == null ? value : JSON.parse(JSON.stringify(value));
}

function cleanText(value, maxLength = 200) {
  return String(value || "")
    .replace(/\u0000/g, "")
    .replace(/[\r\n]+/g, " ")
    .replace(/\s+/g, " ")
    .trim()
    .replace(/^[，,。；;：:\s]+|[，,。；;：:\s]+$/g, "")
    .slice(0, maxLength);
}

function cleanProductName(value) {
  const name = cleanText(value, 40)
    .replace(/^(?:产品|商品|一篇|一个|一份)\s*/i, "")
    .replace(/\s*(?:产品介绍|产品简介|介绍文案|文案)$/i, "")
    .trim();
  if (!name || /^(?:产品|商品|介绍|简介|文案|不知道|还没有|没有)$/i.test(name)) return "";
  return name;
}

export function parseHighlights(value) {
  const text = cleanText(value, 500);
  if (!text || SKIP_PATTERN.test(text)) return [];
  return text
    .replace(/^(?:卖点|亮点|特点)(?:是|有|包括)?[：:\s]*/i, "")
    .split(/[、，,；;|]+/)
    .map((item) => cleanText(item, 80))
    .filter(Boolean)
    .slice(0, 12);
}

export function extractContentSlots(input) {
  const text = String(input || "").trim();
  const productPatterns = [
    /(?:为|给)\s*([^，。！？!?：:\n]{1,30}?)(?:生成|写|撰写|制作)(?:一篇|一个|一份)?(?:产品)?(?:介绍|简介|文案)/i,
    /(?:关于|介绍)\s*([^，。！？!?：:\n]{1,30}?)(?:的)?(?:产品)?(?:介绍|简介|文案)/i,
    /(?:生成|写|撰写)(?:一篇|一个|一份)?\s*([^，。！？!?：:\n]{2,30}?)(?:的)?产品(?:介绍|简介|文案)/i,
  ];
  let productName = "";
  for (const pattern of productPatterns) {
    const match = text.match(pattern);
    productName = cleanProductName(match?.[1]);
    if (productName) break;
  }
  const highlightsMatch = text.match(/(?:卖点|亮点|特点)(?:是|有|包括)?[：:\s]*([^。！？!?\n]+)/i);
  const highlights = parseHighlights(highlightsMatch?.[1] || "");
  return { productName, highlights };
}

export function parseCustomerRecords(input, { requireSeparator = false } = {}) {
  const text = String(input || "").replace(/\r\n?/g, "\n").trim();
  const separator = text.search(/[：:]/);
  if (requireSeparator && separator < 0) return [];
  const payload = separator >= 0 ? text.slice(separator + 1).trim() : text;
  if (!payload) return [];
  return payload
    .split(/\n|；|;/)
    .map((line) => line.trim())
    .filter(Boolean)
    .slice(0, 100)
    .map((line, index) => {
      const parts = line.split(/[，,|]/).map((part) => cleanText(part, 500)).filter(Boolean);
      return {
        id: `chat-customer-${index + 1}`,
        customer: cleanText(parts[0] || `客户 ${index + 1}`, 100),
        note: cleanText(parts.slice(1).join("，") || line, 1000),
      };
    });
}

// 仅在当前应用进程内保存未完成任务参数，不持久化、不上传用户内容。
export class TaskSlotCollector {
  constructor() {
    this.pending = null;
  }

  getPending() {
    return clone(this.pending);
  }

  hasPending() {
    return Boolean(this.pending);
  }

  clear() {
    const previous = this.getPending();
    this.pending = null;
    return previous;
  }

  collectingResult(prompt) {
    return {
      handled: true,
      status: "collecting",
      intent: this.pending.intent,
      stage: this.pending.stage,
      slots: clone(this.pending.slots),
      prompt,
    };
  }

  readyResult() {
    const completed = this.getPending();
    this.pending = null;
    return {
      handled: true,
      status: "ready",
      intent: completed.intent,
      stage: "ready",
      slots: completed.slots,
      prompt: "",
    };
  }

  start(intent, input) {
    if (intent === "content_assistant") {
      const slots = extractContentSlots(input);
      this.pending = {
        intent,
        stage: slots.productName ? "highlights" : "product_name",
        slots,
        createdAt: new Date().toISOString(),
      };
      if (!slots.productName) return this.collectingResult("要介绍什么产品？直接告诉我产品名称就可以。");
      if (!slots.highlights.length) {
        return this.collectingResult(`“${slots.productName}”有哪些主要卖点？请用逗号或顿号分开；也可以回复“跳过”。`);
      }
      return this.readyResult();
    }

    if (intent === "customer_follow_up_assistant") {
      const records = parseCustomerRecords(input, { requireSeparator: true });
      this.pending = {
        intent,
        stage: "customer_records",
        slots: { records },
        createdAt: new Date().toISOString(),
      };
      if (!records.length) {
        return this.collectingResult("请粘贴客户跟进记录，每行一条，例如：\n张三，今天需要回访\n李四，已经签约成交");
      }
      return this.readyResult();
    }

    return { handled: false, status: "unmatched", intent, stage: "", slots: {}, prompt: "" };
  }

  continue(input) {
    if (!this.pending) return { handled: false, status: "unmatched", intent: "unknown", stage: "", slots: {}, prompt: "" };
    const text = String(input || "").trim();
    if (CANCEL_PATTERN.test(text)) {
      const cancelled = this.clear();
      return {
        handled: true,
        status: "cancelled",
        intent: cancelled.intent,
        stage: "cancelled",
        slots: cancelled.slots,
        prompt: "任务已取消，已收集的临时参数没有保存。",
      };
    }

    if (this.pending.intent === "content_assistant" && this.pending.stage === "product_name") {
      const productName = cleanProductName(text);
      if (!productName) return this.collectingResult("我还没识别出产品名称，请只输入名称，例如“七米茶摊”。");
      this.pending.slots.productName = productName;
      this.pending.stage = "highlights";
      return this.collectingResult(`“${productName}”有哪些主要卖点？请用逗号或顿号分开；也可以回复“跳过”。`);
    }

    if (this.pending.intent === "content_assistant" && this.pending.stage === "highlights") {
      this.pending.slots.highlights = parseHighlights(text);
      return this.readyResult();
    }

    if (this.pending.intent === "customer_follow_up_assistant" && this.pending.stage === "customer_records") {
      const records = parseCustomerRecords(text);
      if (!records.length) return this.collectingResult("没有识别到客户记录，请每行输入“客户名称，跟进内容”。");
      this.pending.slots.records = records;
      return this.readyResult();
    }

    const unknown = this.clear();
    return {
      handled: true,
      status: "cancelled",
      intent: unknown.intent,
      stage: "cancelled",
      slots: unknown.slots,
      prompt: "任务上下文已失效，请重新描述需求。",
    };
  }
}

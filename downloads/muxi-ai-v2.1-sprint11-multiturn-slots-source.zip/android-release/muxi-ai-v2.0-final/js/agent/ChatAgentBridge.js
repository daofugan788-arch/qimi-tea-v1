import { TaskSlotCollector } from "./TaskSlotCollector.js";

const CONFIRM_FILE_PATTERN = /^(?:确认|确认整理|继续|继续整理|同意)(?:执行|整理)?[。！!？?\s]*$/i;
const CANCEL_FILE_PATTERN = /^(?:取消|取消整理|停止|停止整理|不用了)[。！!？?\s]*$/i;

function normalizeText(value) {
  return String(value || "").replace(/\r\n?/g, "\n").trim();
}

function abortIfNeeded(signal) {
  if (signal?.aborted) throw new DOMException("任务已取消", "AbortError");
}

function automationReply(route, outcome) {
  const label = outcome.task?.parsed?.label || route.description || "本地任务";
  const stepCount = outcome.task?.actions?.length || 0;
  if (outcome.status === "blocked") {
    return `我识别到这是“${label}”，但它属于当前版本未开放的高风险操作，已经阻止执行。`;
  }
  if (outcome.status === "waiting_confirmation") {
    return `我已经把“${label}”拆成 ${stepCount} 个安全步骤，并打开自动化页面。请先查看风险提示，再手动确认。`;
  }
  if (outcome.status === "cancelled") return `“${label}”已经取消。`;
  if (outcome.status === "failed") return `“${label}”执行失败：${outcome.execution?.error || outcome.task?.error || "请稍后重试"}`;
  return `“${label}”已经处理完成。`;
}

// 将聊天输入接入现有 Router、Planner、TaskQueue、Executor 和 Agent。
// 未识别的普通对话返回 handled:false，继续交给原有本地对话系统。
export class ChatAgentBridge {
  constructor({
    intentRouter,
    automationEngine,
    fileOrganizerAgent,
    localProductivityAgent,
    slotCollector,
    showAutomationTask,
  } = {}) {
    if (!intentRouter || typeof intentRouter.recognize !== "function") throw new Error("ChatAgentBridge 需要 IntentRouter");
    if (!automationEngine || typeof automationEngine.dispatchIntent !== "function") throw new Error("ChatAgentBridge 需要 AutomationEngine");
    if (!fileOrganizerAgent || typeof fileOrganizerAgent.preview !== "function") throw new Error("ChatAgentBridge 需要 FileOrganizerAgent");
    if (!localProductivityAgent || typeof localProductivityAgent.runContent !== "function") {
      throw new Error("ChatAgentBridge 需要 LocalProductivityAgent");
    }
    this.intentRouter = intentRouter;
    this.automationEngine = automationEngine;
    this.fileOrganizerAgent = fileOrganizerAgent;
    this.localProductivityAgent = localProductivityAgent;
    this.slotCollector = slotCollector || new TaskSlotCollector();
    this.showAutomationTask = typeof showAutomationTask === "function" ? showAutomationTask : () => {};
    this.pendingFilePlanId = null;
  }

  hasPendingConfirmation() {
    return Boolean(this.pendingFilePlanId);
  }

  hasPendingCollection() {
    return this.slotCollector.hasPending();
  }

  async handlePendingFileConfirmation(input, signal) {
    if (!this.pendingFilePlanId) return null;
    if (CANCEL_FILE_PATTERN.test(input)) {
      this.pendingFilePlanId = null;
      return {
        handled: true,
        type: "file_organizer_cancelled",
        status: "cancelled",
        reply: "好的，文件整理预览已经取消，没有移动、覆盖或删除任何文件。",
      };
    }
    if (!CONFIRM_FILE_PATTERN.test(input)) return null;
    abortIfNeeded(signal);
    const planId = this.pendingFilePlanId;
    try {
      const output = await this.fileOrganizerAgent.confirm(planId);
      abortIfNeeded(signal);
      this.pendingFilePlanId = null;
      return {
        handled: true,
        type: "file_organizer_confirmation",
        status: "success",
        plan: output.plan,
        reply: "确认已记录。当前版本只完成安全预览，不会实际移动、覆盖或删除下载目录中的文件。",
      };
    } catch (error) {
      this.pendingFilePlanId = null;
      return {
        handled: true,
        type: "file_organizer_confirmation",
        status: "failed",
        reply: `文件整理确认失败：${error?.message || "请重新创建整理计划"}`,
      };
    }
  }

  async handleFileOrganizer(input, route, signal) {
    abortIfNeeded(signal);
    const output = await this.fileOrganizerAgent.preview({ request: input, directory: "Download", files: [] });
    abortIfNeeded(signal);
    this.pendingFilePlanId = output.plan.id;
    const steps = output.plan.steps.map((step, index) => `${index + 1}. ${step.name}`).join("\n");
    return {
      handled: true,
      type: route.intent,
      status: output.plan.status,
      route,
      plan: output.plan,
      requiresConfirmation: output.requiresConfirmation,
      reply: `我已经生成下载目录整理计划：\n${steps}\n\n当前 APK 不能自行读取或移动 Android 文件，只完成安全预览。回复“确认整理”记录确认，回复“取消整理”取消。`,
    };
  }

  async handleContentAssistant(input, route, signal, slots = {}) {
    abortIfNeeded(signal);
    const output = await this.localProductivityAgent.runContent({
      request: input,
      productName: slots.productName,
      highlights: slots.highlights,
    });
    abortIfNeeded(signal);
    return {
      handled: true,
      type: route.intent,
      status: output.plan.status,
      route,
      plan: output.plan,
      reply: `${output.result.title}\n\n${output.result.content}\n\n以上内容由本地模板生成，可以继续告诉我需要调整的方向。`,
    };
  }

  async handleCustomerAssistant(input, route, signal, slots = {}) {
    const records = Array.isArray(slots.records) ? slots.records : [];
    abortIfNeeded(signal);
    const output = await this.localProductivityAgent.runCustomer({ request: input, records });
    abortIfNeeded(signal);
    const summary = Object.entries(output.result.summary).map(([name, count]) => `${name} ${count} 条`).join("、");
    return {
      handled: true,
      type: route.intent,
      status: output.plan.status,
      route,
      plan: output.plan,
      reply: `客户跟进记录已在本地完成整理：${summary}。共处理 ${output.result.total} 条，没有上传或保存客户资料。`,
    };
  }

  async handleSlotResult(result, input, signal, route = null) {
    const effectiveRoute = route || {
      matched: true,
      intent: result.intent,
      toolName: "local_productivity_tool",
      source: "multi_turn_context",
    };
    if (result.status === "collecting" || result.status === "cancelled") {
      return {
        handled: true,
        type: result.intent,
        status: result.status,
        route: effectiveRoute,
        slots: result.slots,
        reply: result.prompt,
      };
    }
    if (result.status === "ready" && result.intent === "content_assistant") {
      return this.handleContentAssistant("帮我生成一篇产品介绍文案", effectiveRoute, signal, result.slots);
    }
    if (result.status === "ready" && result.intent === "customer_follow_up_assistant") {
      return this.handleCustomerAssistant("帮我整理客户跟进记录", effectiveRoute, signal, result.slots);
    }
    return { handled: false, type: result.intent, status: "unmatched", route: effectiveRoute, reply: "" };
  }

  async handleAutomation(input, route, signal) {
    abortIfNeeded(signal);
    const outcome = await this.automationEngine.dispatchIntent(input);
    abortIfNeeded(signal);
    if (["waiting_confirmation", "blocked"].includes(outcome.status) && outcome.task) {
      this.showAutomationTask(outcome.task);
    }
    return {
      handled: true,
      type: route.intent,
      status: outcome.status,
      route,
      task: outcome.task,
      execution: outcome.execution,
      requiresConfirmation: outcome.status === "waiting_confirmation",
      reply: automationReply(route, outcome),
    };
  }

  async handle(rawInput, { signal } = {}) {
    const input = normalizeText(rawInput);
    if (!input) return { handled: false, type: "unknown", status: "unmatched", reply: "" };
    abortIfNeeded(signal);

    const pendingResult = await this.handlePendingFileConfirmation(input, signal);
    if (pendingResult) return pendingResult;

    if (this.slotCollector.hasPending()) {
      return this.handleSlotResult(this.slotCollector.continue(input), input, signal);
    }

    const route = this.intentRouter.recognize(input);
    if (!route.matched) return { handled: false, type: "unknown", status: "unmatched", route, reply: "" };

    if (route.intent === "file_organizer_agent") return this.handleFileOrganizer(input, route, signal);
    if (["content_assistant", "customer_follow_up_assistant"].includes(route.intent)) {
      return this.handleSlotResult(this.slotCollector.start(route.intent, input), input, signal, route);
    }
    if (route.toolName === "automation") return this.handleAutomation(input, route, signal);

    return { handled: false, type: route.intent, status: "unmatched", route, reply: "" };
  }
}

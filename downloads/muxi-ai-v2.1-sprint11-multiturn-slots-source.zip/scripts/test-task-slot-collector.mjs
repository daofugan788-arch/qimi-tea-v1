import assert from "node:assert/strict";
import {
  TaskSlotCollector,
  extractContentSlots,
  parseCustomerRecords,
  parseHighlights,
} from "../js/agent/TaskSlotCollector.js";

const collector = new TaskSlotCollector();

const productStart = collector.start("content_assistant", "帮我生成一篇产品介绍文案");
assert.equal(productStart.status, "collecting");
assert.equal(productStart.stage, "product_name");
assert.equal(collector.hasPending(), true);

const productName = collector.continue("七米茶摊");
assert.equal(productName.status, "collecting");
assert.equal(productName.stage, "highlights");
assert.equal(productName.slots.productName, "七米茶摊");

const productReady = collector.continue("本地现做、价格亲民");
assert.equal(productReady.status, "ready");
assert.equal(productReady.slots.productName, "七米茶摊");
assert.deepEqual(productReady.slots.highlights, ["本地现做", "价格亲民"]);
assert.equal(collector.hasPending(), false);

const directProduct = collector.start(
  "content_assistant",
  "帮我给七米茶摊生成一篇产品介绍文案，卖点是本地现做、价格亲民",
);
assert.equal(directProduct.status, "ready");
assert.equal(directProduct.slots.productName, "七米茶摊");
assert.deepEqual(directProduct.slots.highlights, ["本地现做", "价格亲民"]);

const customerStart = collector.start("customer_follow_up_assistant", "帮我整理客户跟进记录");
assert.equal(customerStart.status, "collecting");
assert.equal(customerStart.stage, "customer_records");

const customerReady = collector.continue("星海商贸，今天需要回访\n远山设计，已经签约成交");
assert.equal(customerReady.status, "ready");
assert.equal(customerReady.slots.records.length, 2);
assert.equal(customerReady.slots.records[0].customer, "星海商贸");
assert.equal(customerReady.slots.records[1].note, "已经签约成交");

const cancelStart = collector.start("content_assistant", "帮我生成一篇产品介绍文案");
assert.equal(cancelStart.status, "collecting");
const cancelled = collector.continue("取消任务");
assert.equal(cancelled.status, "cancelled");
assert.equal(collector.hasPending(), false);
assert.match(cancelled.prompt, /没有保存/);

assert.deepEqual(parseHighlights("卖点是：简单易用，离线可用"), ["简单易用", "离线可用"]);
assert.equal(extractContentSlots("帮我生成一篇产品介绍文案").productName, "");
assert.equal(parseCustomerRecords("客户A，明天回访").length, 1);

console.log(JSON.stringify({
  suite: "muxi-ai-v2.1 Sprint 11 TaskSlotCollector",
  productMultiTurn: "passed",
  productSingleTurn: "passed",
  customerMultiTurn: "passed",
  cancellation: "passed",
  persistence: "none",
  remoteModelUsed: false,
}, null, 2));

import fs from "node:fs/promises";
import path from "node:path";
import { pathToFileURL } from "node:url";

const { JSDOM } = await import(process.env.MUXI_JSDOM_PATH || "jsdom");

const projectRoot = path.resolve(import.meta.dirname, "..");
const html = await fs.readFile(path.join(projectRoot, "index.html"), "utf8");
const dom = new JSDOM(html, {
  url: "https://appassets.androidplatform.net/assets/index.html#home",
  pretendToBeVisual: true,
});

const { window } = dom;
window.scrollTo = () => {};
window.confirm = () => true;
window.requestAnimationFrame = (callback) => setTimeout(callback, 0);
window.navigator.serviceWorker = undefined;

for (const [name, value] of Object.entries({
  window,
  document: window.document,
  navigator: window.navigator,
  localStorage: window.localStorage,
  history: window.history,
  location: window.location,
  CustomEvent: window.CustomEvent,
  DOMException: window.DOMException,
  requestAnimationFrame: window.requestAnimationFrame,
  confirm: window.confirm,
})) {
  Object.defineProperty(globalThis, name, { value, configurable: true, writable: true });
}

await import(`${pathToFileURL(path.join(projectRoot, "js/app.js")).href}?ui-startup-test=${Date.now()}`);

const chatButton = window.document.querySelector('.bottom-nav [data-nav="chat"]');
chatButton.click();

if (!window.document.querySelector('[data-page="chat"]').classList.contains("active")) {
  throw new Error("点击聊天导航后页面没有切换");
}

const input = window.document.querySelector("#message-input");
input.value = "打开设置";
window.document.querySelector("#chat-form").dispatchEvent(new window.Event("submit", {
  bubbles: true,
  cancelable: true,
}));

await new Promise((resolve) => setTimeout(resolve, 30));
if (!window.document.querySelector('[data-page="settings"]').classList.contains("active")) {
  throw new Error("聊天指令没有通过 Agent 切换到设置页");
}

if (!window.document.querySelector("#message-list").textContent.includes("已经处理完成")) {
  throw new Error("Agent 执行结果没有写回聊天记录");
}

console.log("UI 启动成功：模块已加载、聊天指令已路由到 Agent、执行结果已写回");

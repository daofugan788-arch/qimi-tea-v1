# 暮曦 AI V1.0

手机端优先的 AI 语音助手 PWA，支持文字聊天、语音输入、语音播报、长期记忆、离线访问和大模型接口预留。

## 功能

- 主页、聊天、长期记忆、设置
- 安卓 Chrome 语音识别与中文播报
- 自动提取称呼和偏好
- 本地聊天记录与长期记忆
- 数据导入、导出和清除
- PWA 安装、离线缓存和桌面图标
- 安全大模型代理示例

## 运行

```bash
node server/server.mjs
```

打开 `http://localhost:8787`。部署到 HTTPS 后，可在安卓 Chrome 中添加到主屏幕。

## 目录

```text
muxi-ai-v1/
├── index.html
├── manifest.webmanifest
├── service-worker.js
├── css/styles.css
├── js/app.js
├── js/storage.js
├── js/voice.js
├── js/ai-client.js
├── assets/
├── docs/
├── scripts/
└── server/
```

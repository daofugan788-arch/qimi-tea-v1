import { Store, extractMemories, relevantMemories } from "./storage.js";
import { VoiceController } from "./voice.js";
import { AIClient } from "./ai-client.js";

const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];
const state = {
  page: "home",
  memoryFilter: "all",
  sending: false,
  deferredInstallPrompt: null,
  voiceSource: "home",
  requestController: null,
};
const ai = new AIClient(() => Store.getSettings());
let toastTimer;

const elements = {
  pages: $$("[data-page]"),
  navButtons: $$("[data-nav]"),
  messageList: $("#message-list"),
  messageInput: $("#message-input"),
  chatForm: $("#chat-form"),
  typing: $("#typing-indicator"),
  chatVoice: $("#chat-voice-button"),
  homeVoice: $("#home-voice-button"),
  voiceHint: $("#voice-hint"),
  memoryList: $("#memory-list"),
  memoryEmpty: $("#memory-empty"),
  memoryDialog: $("#memory-dialog"),
  memoryForm: $("#memory-form"),
  toast: $("#toast"),
  networkStatus: $("#network-status"),
  installButton: $("#install-button"),
};

function showToast(message) {
  clearTimeout(toastTimer);
  elements.toast.textContent = message;
  elements.toast.classList.add("show");
  toastTimer = setTimeout(() => elements.toast.classList.remove("show"), 2500);
}

function escapeHTML(value) {
  const node = document.createElement("div");
  node.textContent = value;
  return node.innerHTML;
}

function navigate(page) {
  if (!["home", "chat", "memory", "settings"].includes(page)) page = "home";
  state.page = page;
  elements.pages.forEach((section) => section.classList.toggle("active", section.dataset.page === page));
  $$(".bottom-nav [data-nav]").forEach((button) => button.classList.toggle("active", button.dataset.nav === page));
  history.replaceState(null, "", `#${page}`);
  if (page === "chat") {
    renderMessages();
    setTimeout(() => elements.messageInput.focus({ preventScroll: true }), 80);
  }
  if (page === "memory") renderMemories();
  if (page === "settings") loadSettingsForm();
  window.scrollTo({ top: 0, behavior: "smooth" });
}

function updateHome() {
  const settings = Store.getSettings();
  const hour = new Date().getHours();
  const greeting = hour < 6 ? "夜深了" : hour < 11 ? "早上好" : hour < 14 ? "中午好" : hour < 18 ? "下午好" : "晚上好";
  $("#greeting").textContent = greeting;
  $("#user-greeting").textContent = settings.userName ? `${settings.userName}，我在这里。` : "我在这里。";
  $("#date-label").textContent = new Intl.DateTimeFormat("zh-CN", { month: "long", day: "numeric", weekday: "long" }).format(new Date()).toUpperCase();
  $("#brand-name").textContent = settings.assistantName || "暮曦";
  $("#chat-count").textContent = `${Store.getMessages().length} 条消息`;
  $("#memory-count").textContent = `${Store.getMemories().length} 条记忆`;
  document.title = `${settings.assistantName || "暮曦"} AI`;
}

function renderMessages() {
  const messages = Store.getMessages();
  if (!messages.length) {
    const assistant = Store.getSettings().assistantName || "暮曦";
    elements.messageList.innerHTML = `<article class="message assistant"><div class="bubble">晚上好，我是${escapeHTML(assistant)}。你可以打字，也可以点麦克风直接和我说话。</div><time>现在</time></article>`;
  } else {
    elements.messageList.innerHTML = messages.map((message) => {
      const time = new Intl.DateTimeFormat("zh-CN", { hour: "2-digit", minute: "2-digit", hour12: false }).format(new Date(message.createdAt));
      const isError = message.status === "error";
      const retryButton = isError ? `<button class="retry-button" type="button" data-retry-message="${message.id}">重新发送</button>` : "";
      return `<article class="message ${message.role}${isError ? " error" : ""}"><div class="bubble">${escapeHTML(message.content)}${retryButton}</div><time>${time}</time></article>`;
    }).join("");
  }
  requestAnimationFrame(() => window.scrollTo({ top: document.body.scrollHeight, behavior: "smooth" }));
  updateHome();
}

async function sendMessage(rawText, { skipUser = false, errorId = null } = {}) {
  const text = String(rawText || "").trim();
  if (!text || state.sending) return;

  state.sending = true;
  state.requestController = new AbortController();
  if (errorId) Store.deleteMessage(errorId);
  if (!skipUser) Store.addMessage("user", text);
  elements.messageInput.value = "";
  resizeComposer();

  const settings = Store.getSettings();
  let savedCount = 0;
  if (!skipUser && settings.autoMemory) {
    for (const candidate of extractMemories(text)) {
      if (Store.addMemory(candidate.content, candidate.type, "conversation")) savedCount += 1;
    }
  }

  renderMessages();
  elements.typing.classList.remove("hidden");
  try {
    const reply = await ai.reply({
      messages: Store.getMessages(),
      memories: relevantMemories(text),
      signal: state.requestController.signal,
    });
    Store.addMessage("assistant", reply);
    renderMessages();
    if (settings.autoSpeak || state.voiceSource === "voice") voice.speak(reply);
    if (savedCount) showToast("已写入长期记忆");
  } catch (error) {
    if (error?.name === "AbortError") return;
    const message = error?.message || "发送失败，请稍后再试";
    Store.addMessage("assistant", `发送失败：${message}`, {
      status: "error",
      retryText: text,
    });
    renderMessages();
    showToast(message);
  } finally {
    elements.typing.classList.add("hidden");
    state.sending = false;
    state.requestController = null;
    state.voiceSource = "home";
  }
}

function resizeComposer() {
  elements.messageInput.style.height = "auto";
  elements.messageInput.style.height = `${Math.min(elements.messageInput.scrollHeight, 104)}px`;
}

const memoryLabels = {
  identity: { name: "关于我", icon: "我" },
  preference: { name: "偏好", icon: "♡" },
  note: { name: "其他", icon: "✦" },
};

function renderMemories() {
  const memories = Store.getMemories().filter((item) => state.memoryFilter === "all" || item.type === state.memoryFilter);
  elements.memoryList.innerHTML = memories.map((item) => {
    const label = memoryLabels[item.type] || memoryLabels.note;
    const date = new Intl.DateTimeFormat("zh-CN", { year: "numeric", month: "short", day: "numeric" }).format(new Date(item.createdAt));
    return `<article class="memory-item"><span>${label.icon}</span><div><h3>${label.name}</h3><p>${escapeHTML(item.content)}</p><small>${date} · ${item.source === "conversation" ? "对话记忆" : "手动添加"}</small></div><button type="button" data-delete-memory="${item.id}">×</button></article>`;
  }).join("");
  elements.memoryEmpty.classList.toggle("hidden", memories.length > 0);
  updateHome();
}

function loadSettingsForm() {
  const settings = Store.getSettings();
  $("#user-name-input").value = settings.userName;
  $("#assistant-name-input").value = settings.assistantName;
  $("#auto-speak-toggle").checked = settings.autoSpeak;
  $("#auto-memory-toggle").checked = settings.autoMemory;
  $("#remote-ai-toggle").checked = settings.remoteAI;
  $("#ai-base-url-input").value = settings.aiBaseURL;
  $("#ai-api-key-input").value = settings.aiApiKey;
  $("#ai-model-input").value = settings.aiModel;
  $("#context-limit-input").value = settings.contextLimit;
  $("#api-endpoint-input").value = settings.apiEndpoint;
}

function saveSettingsForm() {
  const settings = Store.saveSettings({
    userName: $("#user-name-input").value.trim(),
    assistantName: $("#assistant-name-input").value.trim() || "暮曦",
    autoSpeak: $("#auto-speak-toggle").checked,
    autoMemory: $("#auto-memory-toggle").checked,
    remoteAI: $("#remote-ai-toggle").checked,
    aiBaseURL: $("#ai-base-url-input").value.trim(),
    aiApiKey: $("#ai-api-key-input").value.trim(),
    aiModel: $("#ai-model-input").value.trim(),
    contextLimit: Math.min(100, Math.max(2, Number($("#context-limit-input").value) || 20)),
    apiEndpoint: $("#api-endpoint-input").value.trim(),
  });
  updateHome();
  return settings;
}

function setListening(active) {
  document.body.classList.toggle("listening", active);
  elements.chatVoice.classList.toggle("listening", active);
  elements.voiceHint.textContent = active ? "正在听，请说话……" : "轻触开始语音";
}

const voice = new VoiceController({
  onStart: () => setListening(true),
  onEnd: () => setListening(false),
  onResult: (transcript, isFinal) => {
    elements.messageInput.value = transcript;
    resizeComposer();
    if (isFinal && transcript) {
      navigate("chat");
      state.voiceSource = "voice";
      sendMessage(transcript);
    }
  },
  onError: showToast,
});

elements.navButtons.forEach((button) => button.addEventListener("click", () => navigate(button.dataset.nav)));
elements.chatForm.addEventListener("submit", (event) => { event.preventDefault(); state.voiceSource = "text"; sendMessage(elements.messageInput.value); });
elements.messageInput.addEventListener("input", resizeComposer);
elements.messageInput.addEventListener("keydown", (event) => {
  if (event.key === "Enter" && !event.shiftKey) {
    event.preventDefault();
    state.voiceSource = "text";
    sendMessage(elements.messageInput.value);
  }
});
elements.homeVoice.addEventListener("click", () => { state.voiceSource = "voice"; voice.toggle(); });
elements.chatVoice.addEventListener("click", () => { state.voiceSource = "voice"; voice.toggle(); });
elements.messageList.addEventListener("click", (event) => {
  const button = event.target.closest("[data-retry-message]");
  if (!button) return;
  const failed = Store.getMessages().find((message) => message.id === button.dataset.retryMessage);
  if (failed?.retryText) sendMessage(failed.retryText, { skipUser: true, errorId: failed.id });
});
$("#new-chat-button").addEventListener("click", () => {
  if (confirm("开始新对话？长期记忆不会被删除。")) {
    Store.clearMessages();
    renderMessages();
  }
});

$("#add-memory-button").addEventListener("click", () => elements.memoryDialog.showModal());
$("#close-memory-dialog").addEventListener("click", () => elements.memoryDialog.close());
elements.memoryForm.addEventListener("submit", (event) => {
  event.preventDefault();
  const added = Store.addMemory($("#memory-content-input").value, $("#memory-type-input").value);
  if (added) {
    elements.memoryForm.reset();
    elements.memoryDialog.close();
    renderMemories();
    showToast("记忆已保存");
  }
});
$("#memory-filters").addEventListener("click", (event) => {
  const button = event.target.closest("[data-filter]");
  if (!button) return;
  state.memoryFilter = button.dataset.filter;
  $$("#memory-filters button").forEach((item) => item.classList.toggle("active", item === button));
  renderMemories();
});
elements.memoryList.addEventListener("click", (event) => {
  const button = event.target.closest("[data-delete-memory]");
  if (button && confirm("删除这条记忆？")) {
    Store.deleteMemory(button.dataset.deleteMemory);
    renderMemories();
  }
});

["#user-name-input", "#assistant-name-input", "#auto-speak-toggle", "#auto-memory-toggle"].forEach((selector) => {
  $(selector).addEventListener("change", () => { saveSettingsForm(); showToast("设置已保存"); });
});
$("#save-ai-settings-button").addEventListener("click", () => {
  saveSettingsForm();
  showToast("AI 设置已保存");
});
$("#test-api-button").addEventListener("click", async () => {
  saveSettingsForm();
  const status = $("#api-test-status");
  status.className = "api-test-status";
  status.textContent = "正在测试连接……";
  try {
    await ai.testConnection();
    status.className = "api-test-status success";
    status.textContent = "连接成功，可以开始真实 AI 聊天";
    showToast("模型连接成功");
  } catch (error) {
    status.className = "api-test-status error";
    status.textContent = error?.message || "连接失败";
    showToast(status.textContent);
  }
});
$("#clear-chat-button").addEventListener("click", () => {
  if (confirm("删除全部聊天记录？长期记忆不会被删除。")) {
    Store.clearMessages();
    renderMessages();
    showToast("聊天记录已删除");
  }
});
$("#export-button").addEventListener("click", () => {
  const blob = new Blob([JSON.stringify(Store.exportData(), null, 2)], { type: "application/json" });
  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = `muxi-backup-${new Date().toISOString().slice(0, 10)}.json`;
  link.click();
  setTimeout(() => URL.revokeObjectURL(link.href), 1000);
  showToast("备份已导出");
});
$("#import-button").addEventListener("click", () => $("#import-file").click());
$("#import-file").addEventListener("change", async (event) => {
  const file = event.target.files?.[0];
  if (!file) return;
  try {
    Store.importData(JSON.parse(await file.text()));
    updateHome(); renderMessages(); renderMemories(); loadSettingsForm();
    showToast("备份已导入");
  } catch (error) {
    showToast(error.message || "导入失败");
  }
  event.target.value = "";
});
$("#clear-button").addEventListener("click", () => {
  if (confirm("确定清除全部对话、记忆和设置吗？此操作无法撤销。")) {
    Store.clearAll(); loadSettingsForm(); renderMessages(); renderMemories(); updateHome();
    showToast("本机数据已清除");
  }
});

function updateNetwork() {
  const online = navigator.onLine;
  elements.networkStatus.classList.toggle("offline", !online);
  elements.networkStatus.querySelector("span").textContent = online ? "在线" : "离线";
}
window.addEventListener("online", updateNetwork);
window.addEventListener("offline", updateNetwork);
window.addEventListener("beforeinstallprompt", (event) => {
  event.preventDefault();
  state.deferredInstallPrompt = event;
  elements.installButton.classList.remove("hidden");
});
elements.installButton.addEventListener("click", async () => {
  if (!state.deferredInstallPrompt) return;
  state.deferredInstallPrompt.prompt();
  await state.deferredInstallPrompt.userChoice;
  state.deferredInstallPrompt = null;
  elements.installButton.classList.add("hidden");
});
window.addEventListener("appinstalled", () => showToast("暮曦 AI 已安装到手机"));
if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => navigator.serviceWorker.register("./service-worker.js").catch(() => {}));
}

updateNetwork();
updateHome();
renderMessages();
renderMemories();
loadSettingsForm();
navigate(location.hash.slice(1) || "home");

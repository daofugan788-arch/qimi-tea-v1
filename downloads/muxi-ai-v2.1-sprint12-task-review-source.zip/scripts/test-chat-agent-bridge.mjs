import assert from "node:assert/strict";
import { ChatAgentBridge } from "../js/agent/ChatAgentBridge.js";
import { FileOrganizerAgent } from "../js/agents/FileOrganizerAgent.js";
import { LocalProductivityAgent } from "../js/agents/LocalProductivityAgent.js";
import { ActionExecutor } from "../js/automation/ActionExecutor.js";
import { AutomationEngine } from "../js/automation/AutomationEngine.js";
import { AutomationRepository } from "../js/automation/AutomationRepository.js";

class MemoryStorage {
  constructor() { this.data = new Map(); }
  getItem(key) { return this.data.get(key) || null; }
  setItem(key, value) { this.data.set(key, value); }
  removeItem(key) { this.data.delete(key); }
}

const repository = new AutomationRepository({ storage: new MemoryStorage(), key: "test.chat-agent-bridge" });
const navigated = [];
const actionExecutor = new ActionExecutor({
  navigate: (route) => navigated.push(route),
  showMessage: () => {},
  copyText: async () => {},
  openURL: () => {},
  repository,
});
const automation = new AutomationEngine({ repository, executor: actionExecutor });
const fileOrganizerAgent = new FileOrganizerAgent({
  intentRouter: automation.intentRouter,
  planner: automation.agentPlanner,
  taskQueue: automation.taskQueue,
  executor: automation.agentExecutor,
  toolRegistry: automation.agentExecutor.toolRegistry,
});
const localProductivityAgent = new LocalProductivityAgent({
  intentRouter: automation.intentRouter,
  planner: automation.agentPlanner,
  taskQueue: automation.taskQueue,
  executor: automation.agentExecutor,
  toolRegistry: automation.agentExecutor.toolRegistry,
});
const shownAutomationTasks = [];
const bridge = new ChatAgentBridge({
  intentRouter: automation.intentRouter,
  automationEngine: automation,
  fileOrganizerAgent,
  localProductivityAgent,
  showAutomationTask: (task) => shownAutomationTasks.push(task),
});

let remoteCallCount = 0;
const originalFetch = globalThis.fetch;
globalThis.fetch = async () => {
  remoteCallCount += 1;
  throw new Error("ChatAgentBridge 测试禁止远程请求");
};

try {
  const fallback = await bridge.handle("你好");
  assert.equal(fallback.handled, false);

  const navigation = await bridge.handle("打开设置");
  assert.equal(navigation.handled, true);
  assert.equal(navigation.type, "page_navigation");
  assert.equal(navigation.status, "success");
  assert.deepEqual(navigated, ["settings"]);

  const filePreview = await bridge.handle("帮我整理下载目录");
  assert.equal(filePreview.handled, true);
  assert.equal(filePreview.type, "file_organizer_agent");
  assert.equal(filePreview.plan.steps.length, 3);
  assert.equal(filePreview.requiresConfirmation, true);
  assert.equal(bridge.hasPendingConfirmation(), true);
  assert.match(filePreview.reply, /不会.*移动|不能自行读取或移动/);

  const fileConfirmation = await bridge.handle("确认整理");
  assert.equal(fileConfirmation.handled, true);
  assert.equal(fileConfirmation.status, "success");
  assert.equal(bridge.hasPendingConfirmation(), false);
  assert.match(fileConfirmation.reply, /不会实际移动/);

  const contentStart = await bridge.handle("帮我生成一篇产品介绍文案");
  assert.equal(contentStart.handled, true);
  assert.equal(contentStart.status, "collecting");
  assert.equal(bridge.hasPendingCollection(), true);
  assert.match(contentStart.reply, /产品名称/);

  const contentName = await bridge.handle("七米茶摊");
  assert.equal(contentName.status, "collecting");
  assert.match(contentName.reply, /主要卖点/);

  const contentReview = await bridge.handle("本地现做、价格亲民");
  assert.equal(contentReview.handled, true);
  assert.equal(contentReview.status, "awaiting_confirmation");
  assert.match(contentReview.reply, /确认生成/);

  const contentEdit = await bridge.handle("卖点改成现点现做、清爽解腻");
  assert.equal(contentEdit.status, "awaiting_confirmation");
  assert.match(contentEdit.reply, /现点现做/);

  const content = await bridge.handle("确认生成");
  assert.equal(content.handled, true);
  assert.equal(content.type, "content_assistant");
  assert.equal(content.plan.steps.length, 1);
  assert.match(content.reply, /七米茶摊/);
  assert.match(content.reply, /现点现做/);
  assert.match(content.reply, /本地模板生成/);
  assert.equal(bridge.hasPendingCollection(), false);

  const customerStart = await bridge.handle("帮我整理客户跟进记录");
  assert.equal(customerStart.handled, true);
  assert.equal(customerStart.status, "collecting");
  assert.match(customerStart.reply, /每行一条/);

  const customerReview = await bridge.handle("星海商贸，今天需要回访\n远山设计，已经签约成交");
  assert.equal(customerReview.handled, true);
  assert.equal(customerReview.status, "awaiting_confirmation");
  assert.match(customerReview.reply, /确认整理/);

  const customer = await bridge.handle("确认整理");
  assert.equal(customer.handled, true);
  assert.equal(customer.type, "customer_follow_up_assistant");
  assert.equal(customer.plan.steps.length, 2);
  assert.match(customer.reply, /待跟进 1 条/);
  assert.match(customer.reply, /已成交 1 条/);

  const cancelStart = await bridge.handle("帮我生成一篇产品介绍文案");
  assert.equal(cancelStart.status, "collecting");
  const cancelled = await bridge.handle("取消任务");
  assert.equal(cancelled.status, "cancelled");
  assert.equal(bridge.hasPendingCollection(), false);
  assert.match(cancelled.reply, /临时参数没有保存/);

  const mediumRisk = await bridge.handle("生成启动暮曦的 Termux 命令");
  assert.equal(mediumRisk.handled, true);
  assert.equal(mediumRisk.status, "waiting_confirmation");
  assert.equal(mediumRisk.requiresConfirmation, true);
  assert.equal(shownAutomationTasks.at(-1).id, mediumRisk.task.id);
  assert.match(mediumRisk.reply, /手动确认/);

  const highRisk = await bridge.handle("删除下载目录中的文件");
  assert.equal(highRisk.handled, true);
  assert.equal(highRisk.status, "blocked");
  assert.equal(shownAutomationTasks.at(-1).id, highRisk.task.id);
  assert.match(highRisk.reply, /高风险操作/);

  assert.equal(remoteCallCount, 0);
  assert.equal(automation.taskQueue.getSnapshot().isProcessing, false);
  assert.equal(automation.taskQueue.getSnapshot().pending.length, 0);

  console.log(JSON.stringify({
    suite: "muxi-ai-v2.1 Sprint 12 Task Parameter Review",
    fallbackPreserved: true,
    chatIntents: [
      "page_navigation",
      "file_organizer_agent",
      "content_assistant",
      "customer_follow_up_assistant",
    ],
    fullChain: ["IntentRouter", "AgentPlanner", "TaskQueue", "AgentExecutor", "ToolRegistry"],
    filePreviewConfirmation: "passed",
    multiTurnSlotCollection: "passed",
    parameterReviewAndEditing: "passed",
    mediumRiskConfirmation: "passed",
    highRiskBlocked: true,
    remoteCallCount,
  }, null, 2));
} finally {
  globalThis.fetch = originalFetch;
}

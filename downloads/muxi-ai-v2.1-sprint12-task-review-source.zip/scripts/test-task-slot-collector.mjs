import assert from "node:assert/strict";
import {
  TaskSlotCollector,
  extractContentSlots,
  parseCustomerRecords,
  parseHighlights,
} from "../js/agent/TaskSlotCollector.js";

const collector = new TaskSlotCollector();

const productStart = collector.start("content_assistant", "帮我生成一篇产品介绍文案");
assert.equal(productStart.status, "collecting");
assert.equal(productStart.stage, "product_name");
assert.equal(collector.hasPending(), true);

const productName = collector.continue("七米茶摊");
assert.equal(productName.status, "collecting");
assert.equal(productName.stage, "highlights");
assert.equal(productName.slots.productName, "七米茶摊");

const productReview = collector.continue("本地现做、价格亲民");
assert.equal(productReview.status, "awaiting_confirmation");
assert.equal(productReview.slots.productName, "七米茶摊");
assert.deepEqual(productReview.slots.highlights, ["本地现做", "价格亲民"]);
assert.match(productReview.prompt, /确认生成/);

const renamedProduct = collector.continue("产品名改成七米柠檬茶");
assert.equal(renamedProduct.status, "awaiting_confirmation");
assert.equal(renamedProduct.slots.productName, "七米柠檬茶");

const changedHighlights = collector.continue("卖点改成现点现做、清爽解腻");
assert.equal(changedHighlights.status, "awaiting_confirmation");
assert.deepEqual(changedHighlights.slots.highlights, ["现点现做", "清爽解腻"]);

const productReady = collector.continue("确认生成");
assert.equal(productReady.status, "ready");
assert.equal(productReady.slots.productName, "七米柠檬茶");
assert.equal(collector.hasPending(), false);

const directProduct = collector.start(
  "content_assistant",
  "帮我给七米茶摊生成一篇产品介绍文案，卖点是本地现做、价格亲民",
);
assert.equal(directProduct.status, "awaiting_confirmation");
assert.equal(directProduct.slots.productName, "七米茶摊");
assert.deepEqual(directProduct.slots.highlights, ["本地现做", "价格亲民"]);
assert.equal(collector.continue("确认").status, "ready");

const customerStart = collector.start("customer_follow_up_assistant", "帮我整理客户跟进记录");
assert.equal(customerStart.status, "collecting");
assert.equal(customerStart.stage, "customer_records");

const customerReview = collector.continue("星海商贸，今天需要回访\n远山设计，已经签约成交");
assert.equal(customerReview.status, "awaiting_confirmation");
assert.equal(customerReview.slots.records.length, 2);
assert.equal(customerReview.slots.records[0].customer, "星海商贸");
assert.equal(customerReview.slots.records[1].note, "已经签约成交");

const resetRecords = collector.continue("重新填写");
assert.equal(resetRecords.status, "collecting");
assert.equal(resetRecords.stage, "customer_records");
const replacementReview = collector.continue("青山科技，明天回访");
assert.equal(replacementReview.status, "awaiting_confirmation");
assert.equal(replacementReview.slots.records.length, 1);
const customerReady = collector.continue("确认整理");
assert.equal(customerReady.status, "ready");
assert.equal(customerReady.slots.records[0].customer, "青山科技");

const cancelStart = collector.start("content_assistant", "帮我生成一篇产品介绍文案");
assert.equal(cancelStart.status, "collecting");
const cancelled = collector.continue("取消任务");
assert.equal(cancelled.status, "cancelled");
assert.equal(collector.hasPending(), false);
assert.match(cancelled.prompt, /没有保存/);

assert.deepEqual(parseHighlights("卖点是：简单易用，离线可用"), ["简单易用", "离线可用"]);
assert.equal(extractContentSlots("帮我生成一篇产品介绍文案").productName, "");
assert.equal(parseCustomerRecords("客户A，明天回访").length, 1);

console.log(JSON.stringify({
  suite: "muxi-ai-v2.1 Sprint 12 Task Parameter Review",
  productMultiTurn: "passed",
  productSingleTurn: "passed",
  customerMultiTurn: "passed",
  parameterReview: "passed",
  parameterEditing: "passed",
  cancellation: "passed",
  persistence: "none",
  remoteModelUsed: false,
}, null, 2));

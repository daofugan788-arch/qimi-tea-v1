import fs from "node:fs/promises";
import path from "node:path";

const { JSDOM } = await import(process.env.MUXI_JSDOM_PATH || "jsdom");

const releaseRoot = path.resolve(import.meta.dirname, "../android-release/muxi-ai-v2.0-final");
const html = await fs.readFile(path.join(releaseRoot, "index.html"), "utf8");
const bundle = await fs.readFile(path.join(releaseRoot, "js/app.android-v20102.js"), "utf8");
const dom = new JSDOM(html, {
  url: "https://appassets.androidplatform.net/assets/index.html#home",
  pretendToBeVisual: true,
  runScripts: "outside-only",
});

const { window } = dom;
window.scrollTo = () => {};
window.confirm = () => true;
window.requestAnimationFrame = (callback) => setTimeout(callback, 0);
window.eval(bundle);

if (window.__MUXI_APP_READY__ !== true) throw new Error("Android UI 脚本未完成启动");

window.document.querySelector('.bottom-nav [data-nav="chat"]').click();
if (!window.document.querySelector('[data-page="chat"]').classList.contains("active")) {
  throw new Error("Android 包点击聊天导航后页面没有切换");
}

const input = window.document.querySelector("#message-input");
input.value = "打开设置";
window.document.querySelector("#chat-form").dispatchEvent(new window.Event("submit", {
  bubbles: true,
  cancelable: true,
}));

await new Promise((resolve) => setTimeout(resolve, 30));
if (!window.document.querySelector('[data-page="settings"]').classList.contains("active")) {
  throw new Error("Android 包聊天指令没有通过 Agent 切换到设置页");
}

if (!window.document.querySelector("#message-list").textContent.includes("已经处理完成")) {
  throw new Error("Android 包 Agent 执行结果没有写回聊天记录");
}

console.log("Android UI 启动成功：兼容脚本已加载、聊天指令已路由到 Agent、执行结果已写回");

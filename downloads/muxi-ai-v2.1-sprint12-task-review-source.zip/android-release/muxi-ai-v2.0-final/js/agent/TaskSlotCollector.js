const CANCEL_PATTERN = /^(?:取消|取消任务|停止|停止任务|不用了|先不做了)[。！!？?\s]*$/i;
const SKIP_PATTERN = /^(?:跳过|没有|暂无|用默认|默认即可|直接生成)[。！!？?\s]*$/i;
const CONFIRM_PATTERN = /^(?:确认|确认生成|确认整理|开始|开始生成|开始整理|执行|可以|没问题)[。！!？?\s]*$/i;
const RESET_PATTERN = /^(?:重新填写|重新输入|重填|修改记录|重新提供)[。！!？?\s]*$/i;
const EDIT_PRODUCT_NAME_PATTERN = /^(?:把)?(?:产品名|产品名称|名称)(?:改成|改为|换成|设为|是|[：:])\s*(.+)$/i;
const EDIT_HIGHLIGHTS_PATTERN = /^(?:把)?(?:卖点|亮点|特点)(?:改成|改为|换成|设为|是|[：:])\s*(.+)$/i;

function clone(value) {
  return value == null ? value : JSON.parse(JSON.stringify(value));
}

function cleanText(value, maxLength = 200) {
  return String(value || "")
    .replace(/\u0000/g, "")
    .replace(/[\r\n]+/g, " ")
    .replace(/\s+/g, " ")
    .trim()
    .replace(/^[，,。；;：:\s]+|[，,。；;：:\s]+$/g, "")
    .slice(0, maxLength);
}

function cleanProductName(value) {
  const name = cleanText(value, 40)
    .replace(/^(?:产品|商品|一篇|一个|一份)\s*/i, "")
    .replace(/\s*(?:产品介绍|产品简介|介绍文案|文案)$/i, "")
    .trim();
  if (!name || /^(?:产品|商品|介绍|简介|文案|不知道|还没有|没有)$/i.test(name)) return "";
  return name;
}

export function parseHighlights(value) {
  const text = cleanText(value, 500);
  if (!text || SKIP_PATTERN.test(text)) return [];
  return text
    .replace(/^(?:卖点|亮点|特点)(?:是|有|包括)?[：:\s]*/i, "")
    .split(/[、，,；;|]+/)
    .map((item) => cleanText(item, 80))
    .filter(Boolean)
    .slice(0, 12);
}

export function extractContentSlots(input) {
  const text = String(input || "").trim();
  const productPatterns = [
    /(?:为|给)\s*([^，。！？!?：:\n]{1,30}?)(?:生成|写|撰写|制作)(?:一篇|一个|一份)?(?:产品)?(?:介绍|简介|文案)/i,
    /(?:关于|介绍)\s*([^，。！？!?：:\n]{1,30}?)(?:的)?(?:产品)?(?:介绍|简介|文案)/i,
    /(?:生成|写|撰写)(?:一篇|一个|一份)?\s*([^，。！？!?：:\n]{2,30}?)(?:的)?产品(?:介绍|简介|文案)/i,
  ];
  let productName = "";
  for (const pattern of productPatterns) {
    const match = text.match(pattern);
    productName = cleanProductName(match?.[1]);
    if (productName) break;
  }
  const highlightsMatch = text.match(/(?:卖点|亮点|特点)(?:是|有|包括)?[：:\s]*([^。！？!?\n]+)/i);
  const highlights = parseHighlights(highlightsMatch?.[1] || "");
  return { productName, highlights };
}

export function parseCustomerRecords(input, { requireSeparator = false } = {}) {
  const text = String(input || "").replace(/\r\n?/g, "\n").trim();
  const separator = text.search(/[：:]/);
  if (requireSeparator && separator < 0) return [];
  const payload = separator >= 0 ? text.slice(separator + 1).trim() : text;
  if (!payload) return [];
  return payload
    .split(/\n|；|;/)
    .map((line) => line.trim())
    .filter(Boolean)
    .slice(0, 100)
    .map((line, index) => {
      const parts = line.split(/[，,|]/).map((part) => cleanText(part, 500)).filter(Boolean);
      return {
        id: `chat-customer-${index + 1}`,
        customer: cleanText(parts[0] || `客户 ${index + 1}`, 100),
        note: cleanText(parts.slice(1).join("，") || line, 1000),
      };
    });
}

// 仅在当前应用进程内保存未完成任务参数，不持久化、不上传用户内容。
export class TaskSlotCollector {
  constructor() {
    this.pending = null;
  }

  getPending() {
    return clone(this.pending);
  }

  hasPending() {
    return Boolean(this.pending);
  }

  clear() {
    const previous = this.getPending();
    this.pending = null;
    return previous;
  }

  collectingResult(prompt) {
    return {
      handled: true,
      status: "collecting",
      intent: this.pending.intent,
      stage: this.pending.stage,
      slots: clone(this.pending.slots),
      prompt,
    };
  }

  reviewResult() {
    const slots = clone(this.pending.slots);
    if (this.pending.intent === "content_assistant") {
      const highlights = slots.highlights.length ? slots.highlights.join("、") : "使用本地默认卖点";
      return {
        handled: true,
        status: "awaiting_confirmation",
        intent: this.pending.intent,
        stage: "review",
        slots,
        prompt: `请确认任务参数：\n产品：${slots.productName}\n卖点：${highlights}\n\n回复“确认生成”开始；也可以说“产品名改成……”或“卖点改成……”。`,
      };
    }
    const names = slots.records.slice(0, 5).map((record) => record.customer).join("、");
    const remaining = Math.max(0, slots.records.length - 5);
    return {
      handled: true,
      status: "awaiting_confirmation",
      intent: this.pending.intent,
      stage: "review",
      slots,
      prompt: `已识别 ${slots.records.length} 条客户记录：${names}${remaining ? `等 ${slots.records.length} 位客户` : ""}。\n回复“确认整理”开始；如需替换全部记录，请回复“重新填写”。`,
    };
  }

  readyResult() {
    const completed = this.getPending();
    this.pending = null;
    return {
      handled: true,
      status: "ready",
      intent: completed.intent,
      stage: "ready",
      slots: completed.slots,
      prompt: "",
    };
  }

  start(intent, input) {
    if (intent === "content_assistant") {
      const slots = extractContentSlots(input);
      this.pending = {
        intent,
        stage: slots.productName ? "highlights" : "product_name",
        slots,
        createdAt: new Date().toISOString(),
      };
      if (!slots.productName) return this.collectingResult("要介绍什么产品？直接告诉我产品名称就可以。");
      if (!slots.highlights.length) {
        return this.collectingResult(`“${slots.productName}”有哪些主要卖点？请用逗号或顿号分开；也可以回复“跳过”。`);
      }
      this.pending.stage = "review";
      return this.reviewResult();
    }

    if (intent === "customer_follow_up_assistant") {
      const records = parseCustomerRecords(input, { requireSeparator: true });
      this.pending = {
        intent,
        stage: "customer_records",
        slots: { records },
        createdAt: new Date().toISOString(),
      };
      if (!records.length) {
        return this.collectingResult("请粘贴客户跟进记录，每行一条，例如：\n张三，今天需要回访\n李四，已经签约成交");
      }
      this.pending.stage = "review";
      return this.reviewResult();
    }

    return { handled: false, status: "unmatched", intent, stage: "", slots: {}, prompt: "" };
  }

  continue(input) {
    if (!this.pending) return { handled: false, status: "unmatched", intent: "unknown", stage: "", slots: {}, prompt: "" };
    const text = String(input || "").trim();
    if (CANCEL_PATTERN.test(text)) {
      const cancelled = this.clear();
      return {
        handled: true,
        status: "cancelled",
        intent: cancelled.intent,
        stage: "cancelled",
        slots: cancelled.slots,
        prompt: "任务已取消，已收集的临时参数没有保存。",
      };
    }

    if (this.pending.intent === "content_assistant" && this.pending.stage === "product_name") {
      const productName = cleanProductName(text);
      if (!productName) return this.collectingResult("我还没识别出产品名称，请只输入名称，例如“七米茶摊”。");
      this.pending.slots.productName = productName;
      this.pending.stage = "highlights";
      return this.collectingResult(`“${productName}”有哪些主要卖点？请用逗号或顿号分开；也可以回复“跳过”。`);
    }

    if (this.pending.intent === "content_assistant" && this.pending.stage === "product_name_edit") {
      const productName = cleanProductName(text);
      if (!productName) return this.collectingResult("我还没识别出新的产品名称，请只输入名称，例如“七米茶摊”。");
      this.pending.slots.productName = productName;
      this.pending.stage = "review";
      return this.reviewResult();
    }

    if (this.pending.intent === "content_assistant" && this.pending.stage === "highlights") {
      this.pending.slots.highlights = parseHighlights(text);
      this.pending.stage = "review";
      return this.reviewResult();
    }

    if (this.pending.intent === "content_assistant" && this.pending.stage === "highlights_edit") {
      this.pending.slots.highlights = parseHighlights(text);
      this.pending.stage = "review";
      return this.reviewResult();
    }

    if (this.pending.intent === "customer_follow_up_assistant" && this.pending.stage === "customer_records") {
      const records = parseCustomerRecords(text);
      if (!records.length) return this.collectingResult("没有识别到客户记录，请每行输入“客户名称，跟进内容”。");
      this.pending.slots.records = records;
      this.pending.stage = "review";
      return this.reviewResult();
    }

    if (this.pending.stage === "review") {
      if (CONFIRM_PATTERN.test(text)) return this.readyResult();

      if (this.pending.intent === "content_assistant") {
        const productNameMatch = text.match(EDIT_PRODUCT_NAME_PATTERN);
        if (productNameMatch) {
          const productName = cleanProductName(productNameMatch[1]);
          if (!productName) return this.reviewResult();
          this.pending.slots.productName = productName;
          return this.reviewResult();
        }
        const highlightsMatch = text.match(EDIT_HIGHLIGHTS_PATTERN);
        if (highlightsMatch) {
          this.pending.slots.highlights = parseHighlights(highlightsMatch[1]);
          return this.reviewResult();
        }
        if (/^(?:修改|更改)(?:产品名|产品名称|名称)[。！!？?\s]*$/i.test(text)) {
          this.pending.stage = "product_name_edit";
          return this.collectingResult("新的产品名称是什么？");
        }
        if (/^(?:修改|更改)(?:卖点|亮点|特点)[。！!？?\s]*$/i.test(text)) {
          this.pending.stage = "highlights_edit";
          return this.collectingResult("请重新输入卖点，用逗号或顿号分开；也可以回复“跳过”。");
        }
        return this.reviewResult();
      }

      if (this.pending.intent === "customer_follow_up_assistant") {
        if (RESET_PATTERN.test(text)) {
          this.pending.slots.records = [];
          this.pending.stage = "customer_records";
          return this.collectingResult("请重新粘贴客户跟进记录，每行一条，例如：\n张三，今天需要回访\n李四，已经签约成交");
        }
        return this.reviewResult();
      }
    }

    const unknown = this.clear();
    return {
      handled: true,
      status: "cancelled",
      intent: unknown.intent,
      stage: "cancelled",
      slots: unknown.slots,
      prompt: "任务上下文已失效，请重新描述需求。",
    };
  }
}
